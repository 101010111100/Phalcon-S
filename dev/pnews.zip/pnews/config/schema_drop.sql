DROP TABLE IF EXISTS `pnews`;
DROP TABLE IF EXISTS `pnews_category`;