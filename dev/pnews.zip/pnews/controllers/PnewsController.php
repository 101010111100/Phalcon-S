<?php


namespace P\PNews\controllers;
use P\Common\Libraries\Application;

class PnewsController extends Application
{
    public function indexAction()
    {


    }
}