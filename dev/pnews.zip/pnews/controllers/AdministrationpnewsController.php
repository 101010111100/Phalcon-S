<?php

namespace P\PNews\controllers;
use P\Common\Libraries\Application;

class AdministrationpnewsController extends Application
{
    public function indexAction()
    {


    }

    public function addAction()
    {


    }
}